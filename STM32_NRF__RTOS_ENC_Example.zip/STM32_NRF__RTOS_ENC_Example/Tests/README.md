# Host tests

`make run` builds the crypto/protocol suite and performs a standalone syntax compile of the nRF24L01+ driver using a minimal HAL stub. Device application sources can be syntax-checked with the command documented in `run_checks.sh`.

The host HAL is not a radio emulator and is never part of an STM32 build.

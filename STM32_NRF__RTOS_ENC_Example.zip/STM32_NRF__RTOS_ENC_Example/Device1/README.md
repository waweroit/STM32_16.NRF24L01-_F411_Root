# Device1

Local device ID: `0x01`.

This directory contains CubeMX integration sources rather than a generated `.ioc` project. Follow `INTEGRATION.md`. The application fails closed until a persistent boot-counter backend is supplied.
